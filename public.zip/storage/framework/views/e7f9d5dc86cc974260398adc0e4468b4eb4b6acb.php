<h1>Welcome</h1>

<table border="1">
    <tr>
        <th>Nama</th>
        <th>NPSN</th>
        <th>Alamat</th>
        <th>Kode Pos</th>
        <th>Desa</th>
        <th>Kecamatan</th>
        <th>Kabupaten</th>
        <th>Provinsi</th>
        <th>Status</th>
        <th>Jenjang</th>
    </tr>
    <?php $__currentLoopData = $project; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>

        <td><?php echo e($p->nama); ?></td>
        <td><?php echo e($p->npsn); ?></td>
        <td><?php echo e($p->alamat); ?></td>
        <td><?php echo e($p->kodepos); ?></td>
        <td><?php echo e($p->desa); ?></td>
        <td><?php echo e($p->kecamatan); ?></td>
        <td><?php echo e($p->kabupaten); ?></td>
        <td><?php echo e($p->provinsi); ?></td>
        <td><?php echo e($p->status); ?></td>
        <td><?php echo e($p->jenjang); ?></td>

    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</table>
<?php /**PATH C:\xampp\htdocs\sijakris\resources\views/pages/latihan.blade.php ENDPATH**/ ?>